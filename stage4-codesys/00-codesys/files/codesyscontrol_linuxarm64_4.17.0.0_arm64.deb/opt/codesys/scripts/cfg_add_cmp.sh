#!/bin/bash
#
# helper script to add a component (by name) to a cfg file
# checks if section is already existing (or creates a new one)
# checks if entry is already existing or inserts new entry at highest index
#

RUNTIME_CONFIGFILE=$1
CMP=$2



if [ -z ${CMP} ]; then
    echo "[ERROR] component name argument missing!"
    exit 1
fi
if [ ! -f ${RUNTIME_CONFIGFILE} ]; then
    echo "[ERROR] file does not exist ${RUNTIME_CONFIGFILE}"
    exit 1
fi

echo "[INFO] adding cmp ${CMP} to cfg file ${RUNTIME_CONFIGFILE}"

# check if section is already there:
if  grep -E "^\[ComponentManager\]" ${RUNTIME_CONFIGFILE} >/dev/null ; then
    echo "[INFO] section found"
    if grep -E "^Component.[0-9]*[0-9]=${CMP}"  ${RUNTIME_CONFIGFILE} > /dev/null; then
        echo "[INFO] Component entry already found. No change!"
    else
        # get all lines with Component.xy and use highest
        # restriction: only works until number 99 and no floats! Keep that in mind ;-)
        highest_CmpNr=$(sed -n '/^Component\.\([0-9]*[0-9]\)=.*/ s//\1/p' ${RUNTIME_CONFIGFILE} | sort -u | tail -n 1)
        next_CmpNr=0
        # get line nr of ComponentManager section end
        linenr_endofblock=$(sed -n '/^\[ComponentManager\]$/,/^\[.*\]$/=' ${RUNTIME_CONFIGFILE} | tail -n 2 | head -n 1)
        if [ -z ${highest_CmpNr} ]; then
            echo "no other Component found"
            highest_CmpNr=0        
        fi        
        let "next_CmpNr=${highest_CmpNr} + 1"        

        newentry="Component.${next_CmpNr}=${CMP}"

        # write to CmpSettingsSection, Component might be not set at all
        sed -i "${linenr_endofblock} a ${newentry}" ${RUNTIME_CONFIGFILE}

        echo "writing new Component setting: $newentry at line ${linenr_endofblock}"
    fi
else
    echo "[INFO] section not found"
    
    section="[ComponentManager]"
    newentry="Component.0=${CMP}"

    echo "" >> ${RUNTIME_CONFIGFILE}
    echo "${section}"  >> ${RUNTIME_CONFIGFILE}
    echo "${newentry}"  >> ${RUNTIME_CONFIGFILE}
    echo "" >> ${RUNTIME_CONFIGFILE}
    echo "[INFO] section appended at end of file"
fi


echo "[INFO] adding cmp to cfg file done"
