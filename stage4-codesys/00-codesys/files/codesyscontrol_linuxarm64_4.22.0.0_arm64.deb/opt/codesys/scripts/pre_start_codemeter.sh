#!/bin/sh
#
# systemd pre start helper for codemeter
#
# 

if [ "$(id -u)" -ne 0 ]; then
    echo "[ERROR] You need to run this script privileged!";
    exit 1;
else
    echo "[INFO] $0 privileged: OK"
fi

echo "[INFO] cleaning up codemeter shared memories"
if dpkg -l codemeter-lite >/dev/null; then
    systemctl stop codemeter
fi
rm -f /dev/shm/CME-*
rm -f /dev/shm/sem.CME-*
if dpkg -l codemeter-lite >/dev/null; then
    systemctl start codemeter
fi

echo "[INFO] $0 finished"