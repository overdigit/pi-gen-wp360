#!/bin/sh
#
# systemd pre start helper:
# 1) sources /etc/default/${PRODUCT}
#
# 2) checks:
# - set variables from defaults
# - run as root
# - systemctl available
# - config of USER/GROUP
#
# 3) adds user
# 4) sets permissions on DIRECTORIES
# 5) creates access control list for /dev/cpu_dma_latency
# 

# source of defaults file
# PRODUCT is set in .service file
. /etc/default/${PRODUCT}

if [ -z "${USER_BINARY}" -o -z "${USER_BINARY}" -o -z "${DIRECTORIES}" ]; then
    echo "[ERROR] env vars not properly set, should be set inside /etc/default/${PRODUCT}"
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
    echo "[ERROR] You need to run this script privileged!";
    exit 1;
else
    echo "[INFO] pre_start.sh privileged: OK"
fi

if which systemctl >/dev/null; then
    echo "[INFO] checking for systemctl: OK"
else
    echo "[ERROR] no systemctl found, this script is intended for systemd only!"
    exit 1
fi

# check if USER= and GROUP= in /etc/default/ and systemdunit is fine
SERVICE_USER=$(systemctl show ${PRODUCT}.service | sed -n '/^User=/ s/User=//p')

if [ "${USER_BINARY}" != "${SERVICE_USER}" ]; then
    echo "[ERROR] User configured in ${PRODUCT}.service and /etc/default/${PRODUCT} do not match:  ${USER_BINARY} != ${SERVICE_USER} "
    exit 1
else
    echo "[INFO] checking for configured user: OK"
fi

echo "[INFO] setting ownership of directories"
for d in ${DIRECTORIES}; do
    # set ownership
    chown --recursive ${USER_BINARY}:${GROUP_BINARY} $d;
    # access for group
    chmod -R g+rw $d;
    # no access for others
    chmod -R o-rwx $d;
done

echo "[INFO] pre_start.sh finished"