/**
 * SPDX-License-Identifier: GPL-2.0-only
 * Copyright (c) CODESYS Development GmbH except where noted differently
 * See README for more details
**/

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <xdp/xdp_helpers.h>

#include <linux/if_ether.h> // struct ethhdr, ETH_P_ETHERCAT, ETH_P_PROFINET and ETH_P_LLDP
#include <netinet/in.h>		// htons()

#define MAP_SIZE 128
#define ARP_BUF_SIZE 60 // Used by CODESYS Control. Do not change the value.

/**
 * ##########################################################################################
 * Start taken from https://elixir.bootlin.com/linux/v6.11/source/include/linux/if_vlan.h#L35
 * Copyright (c) Authors of https://elixir.bootlin.com/linux/v6.11/source/include/linux/if_vlan.h
 * ##########################################################################################
 */
struct vlan_hdr {
    __be16 h_vlan_TCI;
    __be16 h_vlan_encapsulated_proto;
};
/**
 * #########################################################################################
 * End taken from https://elixir.bootlin.com/linux/v6.11/source/include/linux/if_vlan.h#L35
 * #########################################################################################
 */

struct
{
    __uint(type, BPF_MAP_TYPE_XSKMAP);
    __uint(key_size, sizeof(int));
    __uint(value_size, sizeof(int));
    __uint(max_entries, MAP_SIZE);
} xsks_map SEC(".maps"); // Used by CODESYS Control. Do not change the name.

struct
{
    __uint(type, BPF_MAP_TYPE_QUEUE);
    __type(value, char[ARP_BUF_SIZE]);
    __uint(max_entries, MAP_SIZE);
} cds_arp_transfer_queue SEC(".maps"); // Used by CODESYS Control. Do not change the name.

struct
{
    __uint(priority, 20);
    __uint(XDP_PASS, 1);
} XDP_RUN_CONFIG(xdp_sock_prog);

SEC("xdp_sock") // Used by CODESYS Control. Do not change the name.
int xdp_sock_prog(struct xdp_md *ctx)
{
   //  bpf_printk("bpf start!");

    void *end = (void*)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;
    
    unsigned long offset;
    unsigned short eth_type;

    struct ethhdr *eth = data;
    offset = sizeof(*eth);

    if (data + offset > end)
    {
       //  bpf_printk("data + sizeof ethhdr is greater than ctx data_end. XDP_DROP");
        return XDP_DROP;
    }

    eth_type = eth->h_proto;
   //  bpf_printk("eth_type is %u (decimal)", eth_type);
    if (eth_type == htons(ETH_P_8021Q) || eth_type == htons(ETH_P_8021AD))
    {
       //  bpf_printk("Found VLAN tag, moving by 4");
        struct vlan_hdr *vlan_hdr;
        vlan_hdr = (void*)eth + offset;
        offset += sizeof(*vlan_hdr);

        if ((void*)eth + offset > end)
        {
           //  bpf_printk("eth + vlan_hdr-offset is greater than end, XDP_DROP");
            return XDP_DROP;
        }
        
        eth_type = vlan_hdr->h_vlan_encapsulated_proto;
       //  bpf_printk("eth_type after moving is %u (decimal)", eth_type);
    }

    if (eth_type == htons(ETH_P_ARP))
    {
       char buffer[ARP_BUF_SIZE] = { 0 };
       int ret = bpf_xdp_load_bytes(ctx, 0, buffer, sizeof(buffer));
       if (ret >= 0)
       {
           if (bpf_map_push_elem(&cds_arp_transfer_queue, buffer, BPF_ANY) >= 0)
           {
               // bpf_printk("successfully pushed to ARP queue");
           }
           // else
           // {
           //     bpf_printk("failed to push to ARP queue!");
           // }
       }
       // else
       // {
       //     bpf_printk("failed to copy ARP packet to buffer!");
       // }
    }

    if (eth_type == htons(ETH_P_PROFINET) || eth_type == htons(ETH_P_ETHERCAT) || eth_type == htons(ETH_P_LLDP))
    {
       //  bpf_printk("is EC or PN or LLDP header");
        int index = ctx->rx_queue_index;
        if (bpf_map_lookup_elem(&xsks_map, &index))
        {
           //  bpf_printk("map lookup successfull. bpf_redirect_map");
            return bpf_redirect_map(&xsks_map, index, 0);
        }
       //  else
       //  {
       //      bpf_printk("bpf_map_lookup_elem failed.");
       //  }
    }
   //  else
   //  {
   //      bpf_printk("not EC or PN or LLDP header");
   //  }

   //  bpf_printk("bpf end. XDP_PASS");
    return XDP_PASS;
}

char _license[] SEC("license") = "GPL-2.0-only";